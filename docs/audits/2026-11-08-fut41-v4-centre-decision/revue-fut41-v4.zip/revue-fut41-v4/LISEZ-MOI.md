# Revue FUT-41 / FUT-22 · Prototype V4 du centre de décision

Archive de revue préparée le 8 novembre 2026. Les chemins reprennent ceux du dépôt `futuree-app/future-e`.

**Provenance**
- Branche `explore/fut-41-v4-centre-decision`, commit `64ebfdf9` (local, non poussé), depuis `main` `b818ba5c`.
- Références V3.3 : branche `explore/fut-41-centre-decision`, commit `2d9350df`.

**Toutes les données sont fictives.** Les communes portent des codes 99xxx qui n'existent pas. Adresses, annonces, analyses, mesures et preuves sont inventées. Aucun compte réel, aucun paiement, aucun appel de modèle.

## Par où commencer

1. `docs/audits/2026-11-08-fut41-v4-centre-decision/README.md` : le compte rendu (audit, vision, navigation, contrat de comparabilité, fonctionnalités, Pass, plan par lots, prompt du premier lot, décisions Z1 à Z11).
2. `docs/audits/2026-11-08-fut41-v4-centre-decision/captures/` : 91 captures. Nom : `{n°}-{vue}-{largeur}-{sombre|clair}.png`.
   - 01 à 14 : la matrice des vues ;
   - 20 à 26 : les gestes (ajout, face-à-face, vue d'ensemble, réponse et note, écart, Et si, mise à jour).
3. `src/components/prototypes/fut41-v4/modele.ts` : le contrat proposé, en logique pure, et ses tests (`modele.test.ts`).

## Contenu

| Dossier ou fichier | Rôle |
|---|---|
| `src/components/prototypes/fut41-v4/` | **Sources du prototype** : modèle et tests, état et gestes, cinq vues, panneau Et si, ajout assisté, styles. |
| `src/components/prototypes/fut41-v4/scenarios.ts` | **Fixtures** : le Projet (révisions 2 et 3), sept logements, leurs analyses et vérifications, l'analyse simulée, les 12 scénarios. |
| `src/app/dev/centre-decision/page.tsx` | Route de développement, qui renvoie 404 en production. |
| `src/components/releve/primitives.tsx`, `releve.module.css`, `marge.ts` | **Dépendances visuelles** : les primitives de production du Relevé. Seule la constante `TEINTE_REGISTRE` de `marge.ts` sert ici ; ses autres imports ne sont pas inclus. |
| `src/components/report/echelle-geometry.ts` | Géométrie de l'emblème des trois échelles. |
| `src/app/design-tokens.css` | Jetons `--r-*` (Relevé), `--reg-*` (registres) et `--m-*` (mouvement), en thèmes sombre et clair. |
| `src/lib/motion.ts`, `DESIGN.md` | Grammaire du mouvement et charte v3. |
| `docs/audits/2026-11-08-fut41-v4-centre-decision/` | Compte rendu, annexe (audit du lot 2), recette (`outils/recette.cjs`, `recette.json`), captures. |
| `references-v3-3/` | Notes FUT-22 (comparabilité) et FUT-41 (validité du point), protocole à trois personnes, README V3.2, audit d'articulation FUT-86, prototype V3.3 (HTML autonome). |
| `MANIFESTE.sha256` | Empreinte de chaque fichier. |

## Lancer le prototype

Dans une copie du dépôt sur la branche indiquée, avec les dépendances installées :

```
NEXT_PUBLIC_SUPABASE_URL=http://127.0.0.1:9 NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=cle-fictive \
  npx next dev --webpack -p 3041
# http://localhost:3041/dev/centre-decision   (scénarios : ?s=s1 … ?s=s8, ?s=vide, ?s=un)
node --test src/components/prototypes/fut41-v4/modele.test.ts
```

L'archive seule ne suffit pas à lancer l'application : elle contient le prototype et ses dépendances visuelles, pas tout le dépôt. Les captures et le prototype V3.3 (`references-v3-3/prototype-v3-3.html`, autonome) se lisent sans installation.

## Limites à garder en tête pendant la revue

- Les règles de comparaison affichées sont le contrat **proposé** par la note FUT-22 ; le moteur de production ne les applique pas encore.
- Les effets des réponses aux vérifications sont écrits à la main dans les fixtures. En production, ils viendraient du moteur (FUT-21).
- Le Pass Recherche est une hypothèse de revue : aucun prix ni quota n'est décidé (FUT-49).
- Non vérifié : Safari, lecteur d'écran, téléphone physique, compte connecté, compréhension par des personnes réelles.
